var numbers =[1,4,9]
console.log(numbers)

var element = numbers.pop()
console.log(element)
console.log(numbers)

var element = numbers.pop()
console.log(element)
console.log(numbers)

var length=numbers.push(20)
console.log(numbers)

 length=numbers.push(30)
 length=numbers.push(5)
 length=numbers.push(8)
console.log(numbers)


