let marks = [10,20,30]

for(let m of marks)
{
    console.log(m)
}