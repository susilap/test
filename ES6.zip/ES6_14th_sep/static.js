class staticmem{
    static disp()
    {
        console.log('static function called')
    }
}

staticmem.disp()