function userDetails(values){
    console.log(values)
}

var myset = new Set()
myset.add("John")
myset.add("Doe")
myset.forEach(userDetails)