function add(a,b,c)
{
    return a+b+c;
}


const arr=[10,20,30]
console.log('sum is:',add(...arr))
console.log('sum is:',add(...[1,2,3]))