import c from './company1.js'
console.log(c.getName())

c.setName: function(newName){
    
}