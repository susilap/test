var message ="hello world"
console.log(message)