function car()
{
    this.make ="ford"
    this.model="F123"
}

var obj =new car()
console.log(obj.make)
console.log(obj.model)