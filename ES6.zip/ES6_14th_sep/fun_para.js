function add(n1,n2)

{
    var sum =n1+n2
    console.log("the sum of the values entered"+sum)
}

add(12,13)