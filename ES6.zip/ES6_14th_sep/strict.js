
x=3.14
myFunction();

function myFunction()
{
    "use strict"
    y=3.56;
}
