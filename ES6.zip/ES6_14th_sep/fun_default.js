function add(a,b=1)
{
    return a+b;
}

console.log(add(4))