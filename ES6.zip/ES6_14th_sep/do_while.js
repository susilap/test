var n=10

do{
    if(n==1)
    continue;
    console.log(n)
    n--
}while(n>=0)