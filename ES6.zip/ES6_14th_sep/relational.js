var num1=5;
var num2=9;
console.log("val of num1"+num1);
console.log("val of num2"+num2);

var res=num1>num2
console.log("num1 greater than num2:"+res)

var res=num1<num2
console.log("num1 less than num2:"+res)

var res=num1>=num2
console.log("num1 greater than or equal num2:"+res)

var res=num1<=num2
console.log("num1 less than or equal num2:"+res)

var res=num1==num2
console.log("num1  equal num2:"+res)

var res=num1!=num2
console.log("num1 not equal num2:"+res)