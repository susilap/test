var  names =new Array("Anee","Tom","Jack","Jill")

for(var i=0;i<names.length;i++)
{
    console.log(names[i])
}