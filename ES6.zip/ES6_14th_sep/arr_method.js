var alpha=["a","b","c"]
var numeric =[1,2,3]

var alphanumeric = alpha.concat(numeric)

console.log(alphanumeric)