var set = new Set()

set.add(10);
set.add(10);
set.add(10);
set.add(20);
set.add(30);
console.log(set.size)
set.delete(10)
console.log(set.size)

set.clear();
console.log(set.size)