function retstr()
{
    return "hello world"
    
}

var val =retstr()
console.log(val)