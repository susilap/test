var fruits = new Array("mango","orange","kiwi","apple")

var sorted =fruits.sort()

console.log(sorted)