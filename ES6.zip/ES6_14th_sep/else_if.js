var num=2
if(num>0)
{
    console.log(num+=" positive")
}else if(num<0)
{
    console.log(num+="is negative")
}else{
    console.log(num+="is neither positive or negative")
}