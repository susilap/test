class polygon{
    constructor(height,width)
    {
        this.h =height;
        this.w= width;
    }

    test()
    {
        console.log("the height of the polygon:",this.h)
        console.log("the width of the polygon:",this.w)
    }
}

var obj = new polygon(10,20)
obj.test();