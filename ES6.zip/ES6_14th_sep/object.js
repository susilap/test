var mycar= new Object()
mycar.make="ford"
mycar.model = "mustang"
mycar.year = 1987


console.log(mycar["make"])
console.log(mycar["model"])
console.log(mycar["year"])