var fun123 =function(x,y) {
    return x*y
}

function product()
{
    var result;
    result =fun123(10,200)
    console.log("the product :"+result)
}


product()